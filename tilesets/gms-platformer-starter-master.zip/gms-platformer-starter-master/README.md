GMS Platformer Starter Project Files
===============
These files and tutorial were created for old Game Maker 8, but they can be transformed into a Game Maker Studio 2 project.

I'll be posting a link to the playlist after I record my first video.

Game Design Students! Here's what you need to do:
------------
1. Click the fork button
2. Add it to your list of repos
3. begin work on your own repository
